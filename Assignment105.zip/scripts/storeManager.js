function saveUser(user){
    //load old data
    let data=readUsers();
    //merge data
    data.push(user);
    // convert object into string for local storage
    let val= JSON.stringify(data);
    localStorage.setItem("users", val);

}

function readUsers(){
    let data=localStorage.getItem("users");
    if(!data){
        return [];// empty array for 1st registration
    } else {
        let list=JSON.parse(data); //string into object
        return list; //return obj, not string
    }
}