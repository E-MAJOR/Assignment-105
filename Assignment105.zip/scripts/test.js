function hello(person){
    console.log("hello"+person);
    return "Traveling to London";
}

// hello("Mark");
// console.log(document.getElementById("menu-container"));
// console.log(document.getElementsByClassName("menu"));
// console.log(document.getElementsByTagName("a"));

// let menu=document.getElementById("menu-container").style.display="none";

// let menu=document.getElementById("menu-container");
// //stores the DOM to access later so dont need to go through the menu-container again
// //so dont have to search the whole html page (DOM) to find, as is needed above, 

// menu.style.display="block";

//https://api.jquery.com/
// use 3.6
 jQuery("#menu-container");
 $("#menu-container").hide();
 $("#menu-container").show();//by id
 $("#menu-container").css({'background':'gray'});
 $(".menu").css({'background':'gray'}); // by class
 jQuery("body").css({'background':'#dedede'});


